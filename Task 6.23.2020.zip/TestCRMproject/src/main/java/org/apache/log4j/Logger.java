package org.apache.log4j;

public class Logger {

}
