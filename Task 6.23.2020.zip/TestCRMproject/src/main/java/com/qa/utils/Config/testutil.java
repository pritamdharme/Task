package com.qa.utils.Config;

import com.qa.pages.TestBase;

public class testutil extends TestBase {
	
	public static long PAGE_LOAD_TIMEOUT = 20;
	public static long IMPLICIT_WAIT = 20;

	
	

}
