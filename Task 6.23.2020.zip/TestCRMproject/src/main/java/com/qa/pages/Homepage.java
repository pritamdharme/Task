package com.qa.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Homepage extends TestBase {
	
	@FindBy(xpath="//li[@class='global-header-nav-user ng-scope dropdown']")
	WebElement user;
	
	
	@FindBy(linkText="Collection")
	WebElement Collection;
	
	@FindBy(linkText="Brass: Birmingham")
	WebElement gameselect;
	
	@FindBy(xpath="//button[@class='btn btn-xs btn-empty feature-action-icon']//span[@class='glyphicon glyphicon-stats']")
	WebElement LanguageDependence;
	
   
	@FindBy(tagName="table")
	WebElement table;
	
	@FindBy(xpath="//tbody[contains(@class,'ng-scope')]//tr")
	List<WebElement> rowNum;
	
	@FindBy(xpath="//tr[1]//td[3]")
	WebElement col;
	
	String F1="//tr[";
	String F2="]//td[3]";
	ArrayList<Integer> ar=new ArrayList<Integer>();
	
public Homepage()
{
	PageFactory.initElements(driver, this);
}
public void selectcollection() throws InterruptedException
{
	Thread.sleep(100);
	user.click();

	Collection.click();
	
}

public void selectgame() throws InterruptedException
{
	Thread.sleep(100);
	gameselect.click();
	
}

public void LanguageDependencepoll() throws InterruptedException
{
	Thread.sleep(100);
	LanguageDependence.click();
	
	
}

public void mostvotedLanguageDependence() throws InterruptedException

{
	
	for(int i=1;i<5;i++)
	{
		
		String Final=F1+i+F2;
		System.out.println(Final);
        String count=driver.findElement(By.xpath(Final)).getText();
        System.out.println(count);
        Integer Iprice=Integer.parseInt(count);
	    System.out.println(Iprice);
      	ar.add(Iprice);
      	
		
	}
	Collections.sort(ar);
	System.out.println("mostvotedLanguageDependenceis"+ ar.get(0));
    System.out.println(ar.get(ar.size()-1));
	
}
}

