package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Login extends TestBase

{
	@FindBy(xpath="//input[@id='inputUsername']")
	WebElement username;
	
	@FindBy(id="inputPassword")
	WebElement password;
	
	@FindBy(xpath="//button[@class='btn btn-sm']")
	WebElement SigIn;
	
	@FindBy(xpath="/div[@class='modal-content']")
	WebElement Modal;
	
	
	@FindBy(xpath="//button[@class='btn btn-primary']")
	WebElement signUpBtn;
	

public Login()
{
	PageFactory.initElements(driver, this);
}

public String validateLoginPageTitle(){
	return driver.getTitle();
}

public Homepage login(String un, String pwd) throws InterruptedException
{
	SigIn.click();
	username.sendKeys(un);
	password.sendKeys(pwd);
	signUpBtn.click();
	return new Homepage();

}

}