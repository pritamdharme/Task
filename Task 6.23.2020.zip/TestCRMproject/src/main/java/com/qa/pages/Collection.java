package com.qa.pages;

public class Collection extends TestBase{
	
	Homepage hp;
	   Login lp;
	   

}
