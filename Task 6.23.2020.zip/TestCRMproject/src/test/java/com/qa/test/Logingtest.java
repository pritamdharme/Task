package com.qa.test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.pages.Homepage;
import com.qa.pages.Login;
import com.qa.pages.TestBase;

public class Logingtest extends TestBase {
	
	Login lp;
	Homepage hm;
	
	public Logingtest()
	{
		super();
		
	}
	
	@BeforeMethod
	public void setUp()
	{
		initialization();
		lp = new Login();
}
	@Test()
	public void loginTest() throws InterruptedException{
		
		Thread.sleep(500);
		hm = lp.login(prop.getProperty("username"), prop.getProperty("password"));
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	
}
