package com.qa.test;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.pages.Homepage;
import com.qa.pages.Login;
import com.qa.pages.TestBase;

public class HomePageTest extends TestBase {
	
   Homepage hp;
   Login lp;
	public HomePageTest()
	{
		super();
		
	}
	
	@BeforeMethod
	public void setUp() throws InterruptedException {
		initialization();
		lp = new Login();
		hp = lp.login(prop.getProperty("username"), prop.getProperty("password"));
	}
		@Test(priority=1)
		public void clickoncollection() throws InterruptedException{
			Thread.sleep(100);
			hp.selectcollection();
			
}
	
		
		@Test(priority=2)
		public void mostvotedLanguageDependence () throws InterruptedException
		{
			hp.selectgame();
			JavascriptExecutor js = (JavascriptExecutor) driver;
		    js.executeScript("javascript:window.scrollBy(250,350)");
			hp.LanguageDependencepoll();
			hp.mostvotedLanguageDependence();
		}
		

}
